##############################
Static directory for tinypages
##############################

We need this README file to make sure the ``_static`` directory gets created
in the installation.  The tests check for warnings in builds, and, when the
``_static`` directory is absent, this raises a warning.
